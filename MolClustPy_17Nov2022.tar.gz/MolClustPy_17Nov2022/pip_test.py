# -*- coding: utf-8 -*-
"""
Created on Fri Sep 30 14:38:03 2022

@author: Ani Chattaraj
"""

from nfsim_data_analyzer import *
from DataViz_NFsim import * 
from MultiRun_BNG import * 
from glob import glob 

#from clusteranalyzer import *  
# list of bngl files 
files = glob('C:/Users/chatt/Desktop/CCAM_tools/nfsimPy_01Nov/test_dataset/single_concentration_file/neph_nck_nwasp_20_60_30uM.bngl')


for file in files:
    # run multiple trials
    simObj = BNG_multiTrials(file, t_end=0.02, steps=20, numRuns=10)
    molecules, vals, counts = simObj.getMolecules()
    '''
    print(simObj)
    #print(molecules, vals, counts)
    print()
    #simObj.runTrials(delSim=False)
    
    print()
    # analyze data across multiple trials
    outpath = simObj.getOutPath()
    
    nfsObj = NFSim_output_analyzer(outpath)
    nfsObj.process_gdatfiles()
    nfsObj.process_speciesfiles(molecules, counts=counts, valency=vals)
    
    plotTimeCourse(outpath, obsList=[2,4,6,7,8])
    plotBondsPerMolecule(outpath)
    plotBoundFraction(outpath)
    plotBondCounts(outpath, molecules=molecules)
    '''
    outpath = simObj.getOutPath()
    #plotMolecularDistribution(outpath, molecules=[], width=0.2, alpha=0.6)
    #plotClusterComposition(outpath, specialClusters=[2, 4 , 8], width=0.2, alpha=0.5)
    plotClusterDist(outpath, sizeRange=[1,20,100])
    
    
    
    
    
    
